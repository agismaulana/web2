<ul>
    <li>
        <a href="<?= base_url(); ?>/pages/dashboard/home.php">Home</a>
    </li>
    <li>
        <a href="<?= base_url(); ?>/pages/members/index.php">Member</a>
    </li>
    <li>
        <a href="<?= base_url(); ?>/pages/coupons/index.php">Kupon</a>
    </li>
    <li>
        <a href="<?= base_url(); ?>/pages/user-coupons/index.php">User Kupon</a>
    </li>
    <li>
        <a href="<?= base_url();?>/pages/auth/logout.php">Logout</a>
    </li>
</ul>
<?php 

include $_SERVER['DOCUMENT_ROOT'].'/pertemuan18/config/session.php';
include $_SERVER['DOCUMENT_ROOT'].'/pertemuan18/functions/get.php';

logout();
<?php $judul = 'Home'; ?>
<?php include $_SERVER["DOCUMENT_ROOT"] . "/pertemuan18/pages/layout/head.php" ; ?>

<h1>
    Selamat Datang Di Halaman Dashboard
</h1>

<?php include $_SERVER["DOCUMENT_ROOT"] . "/pertemuan18/pages/layout/foot.php" ; ?>
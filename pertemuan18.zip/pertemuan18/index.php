<?php 

include $_SERVER['DOCUMENT_ROOT'].'/pertemuan18/config/session.php';

is_login();
is_not_login();
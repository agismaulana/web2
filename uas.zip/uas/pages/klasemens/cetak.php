<?php 

    include $_SERVER['DOCUMENT_ROOT']."/uas/functions.php";

    cetakKlasemens();

    
?>


<?php 
$conn = mysqli_connect('localhost', 'root', '', 'uas_web2');

if(!$conn) 
    die('koneksi gagal');

    
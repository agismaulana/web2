<?php

header('location: /uas/pages/home.php');
exit;